% Simscape(TM) Multibody(TM) version: 7.4

% This is a model data file derived from a Simscape Multibody Import XML file using the smimport function.
% The data in this file sets the block parameter values in an imported Simscape Multibody model.
% For more information on this file, see the smimport function help page in the Simscape Multibody documentation.
% You can modify numerical values, but avoid any other changes to this file.
% Do not add code to this file. Do not edit the physical units shown in comments.

%%%VariableName:smiData


%============= RigidTransform =============%

%Initialize the RigidTransform structure array by filling in null values.
smiData.RigidTransform(19).translation = [0.0 0.0 0.0];
smiData.RigidTransform(19).angle = 0.0;
smiData.RigidTransform(19).axis = [0.0 0.0 0.0];
smiData.RigidTransform(19).ID = '';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(1).translation = [127.5 4.0000000000000036 0];  % mm
smiData.RigidTransform(1).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(1).axis = [0.57735026918962584 0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(1).ID = 'B[Frame-1:-:Wheel-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(2).translation = [44.106374618189108 5.0000000000000355 -1.9046569349794069];  % mm
smiData.RigidTransform(2).angle = 2.0943951023931957;  % rad
smiData.RigidTransform(2).axis = [0.57735026918962584 -0.57735026918962573 0.57735026918962573];
smiData.RigidTransform(2).ID = 'F[Frame-1:-:Wheel-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(3).translation = [127.50000000000003 -39.000000000000007 9.9999999999999805];  % mm
smiData.RigidTransform(3).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(3).axis = [-0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(3).ID = 'B[Frame-1:-:Rear_axle-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(4).translation = [1.7763568394002505e-15 2.8421709430404007e-14 -12.000000000000085];  % mm
smiData.RigidTransform(4).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(4).axis = [0.70710678118654757 0.70710678118654757 5.5511151231257827e-17];
smiData.RigidTransform(4).ID = 'F[Frame-1:-:Rear_axle-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(5).translation = [-18.00000000000005 22.000000000000007 0];  % mm
smiData.RigidTransform(5).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(5).axis = [0.57735026918962584 0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(5).ID = 'B[Wheel_frame-1:-:Front_axle-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(6).translation = [9.5923269327613525e-14 38.000000000001897 4.2632564145606011e-14];  % mm
smiData.RigidTransform(6).angle = 2.0943951023931957;  % rad
smiData.RigidTransform(6).axis = [0.57735026918962584 -0.57735026918962606 0.57735026918962529];
smiData.RigidTransform(6).ID = 'F[Wheel_frame-1:-:Front_axle-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(7).translation = [-18.00000000000005 22.000000000000007 0];  % mm
smiData.RigidTransform(7).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(7).axis = [0.57735026918962584 0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(7).ID = 'B[Wheel_frame-1:-:]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(8).translation = [74.221465747620371 89.133587905448593 56.202325412919521];  % mm
smiData.RigidTransform(8).angle = 1.61871856555558;  % rad
smiData.RigidTransform(8).axis = [-0.21380836888311239 -0.21380836888311167 0.9531904126621743];
smiData.RigidTransform(8).ID = 'F[Wheel_frame-1:-:]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(9).translation = [0 0 0];  % mm
smiData.RigidTransform(9).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(9).axis = [-0.57735026918962584 -0.57735026918962584 -0.57735026918962584];
smiData.RigidTransform(9).ID = 'B[Front_axle-2:-:Wheel-4]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(10).translation = [9.0594198809412774e-14 11.000000000000506 5.5067062021407764e-14];  % mm
smiData.RigidTransform(10).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(10).axis = [0.57735026918962584 -0.57735026918962606 0.57735026918962551];
smiData.RigidTransform(10).ID = 'F[Front_axle-2:-:Wheel-4]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(11).translation = [0 0 0];  % mm
smiData.RigidTransform(11).angle = 0;  % rad
smiData.RigidTransform(11).axis = [0 0 0];
smiData.RigidTransform(11).ID = 'B[Rear_axle-1:-:Wheel-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(12).translation = [-2.6645352591003757e-15 -7.0000000000000862 -5.7509552675583109e-14];  % mm
smiData.RigidTransform(12).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(12).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(12).ID = 'F[Rear_axle-1:-:Wheel-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(13).translation = [0 0 0];  % mm
smiData.RigidTransform(13).angle = 0;  % rad
smiData.RigidTransform(13).axis = [0 0 0];
smiData.RigidTransform(13).ID = 'B[Rear_axle-1:-:Wheel-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(14).translation = [-5.6843418860808015e-14 -147.00000000000014 -7.2164496600635175e-15];  % mm
smiData.RigidTransform(14).angle = 2.0943951023931957;  % rad
smiData.RigidTransform(14).axis = [0.57735026918962573 -0.57735026918962573 0.57735026918962562];
smiData.RigidTransform(14).ID = 'F[Rear_axle-1:-:Wheel-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(15).translation = [62.5 -44 -133.61685];  % mm
smiData.RigidTransform(15).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(15).axis = [-0.57735026918962584 -0.57735026918962584 -0.57735026918962584];
smiData.RigidTransform(15).ID = 'B[Frame-1:-:Pin-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(16).translation = [0 -26 2.1316282072803006e-14];  % mm
smiData.RigidTransform(16).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(16).axis = [-0.57735026918962584 -0.57735026918962584 -0.57735026918962584];
smiData.RigidTransform(16).ID = 'F[Frame-1:-:Pin-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(17).translation = [0 0 0];  % mm
smiData.RigidTransform(17).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(17).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(17).ID = 'B[Pin-1:-:Wheel_frame-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(18).translation = [-11.000000000000842 45.000000000000007 -8.1712414612411521e-14];  % mm
smiData.RigidTransform(18).angle = 2.0943951023931944;  % rad
smiData.RigidTransform(18).axis = [0.5773502691896254 -0.57735026918962573 0.57735026918962618];
smiData.RigidTransform(18).ID = 'F[Pin-1:-:Wheel_frame-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(19).translation = [8.7315850632624095 130.13358790544859 196.14852083668114];  % mm
smiData.RigidTransform(19).angle = 0;  % rad
smiData.RigidTransform(19).axis = [0 0 0];
smiData.RigidTransform(19).ID = 'RootGround[Frame-1]';


%============= Solid =============%
%Center of Mass (CoM) %Moments of Inertia (MoI) %Product of Inertia (PoI)

%Initialize the Solid structure array by filling in null values.
smiData.Solid(6).mass = 0.0;
smiData.Solid(6).CoM = [0.0 0.0 0.0];
smiData.Solid(6).MoI = [0.0 0.0 0.0];
smiData.Solid(6).PoI = [0.0 0.0 0.0];
smiData.Solid(6).color = [0.0 0.0 0.0];
smiData.Solid(6).opacity = 0.0;
smiData.Solid(6).ID = '';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(1).mass = 0.0006628760499074463;  % kg
smiData.Solid(1).CoM = [0 12.919431279620852 0];  % mm
smiData.Solid(1).MoI = [0.046328756363451726 0.0027642088360773187 0.046328756363451733];  % kg*mm^2
smiData.Solid(1).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(1).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(1).opacity = 1;
smiData.Solid(1).ID = 'Front_axle*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(2).mass = 0.03523671949622912;  % kg
smiData.Solid(2).CoM = [62.499999999999872 -1.5196954756418608 -27.587274700446901];  % mm
smiData.Solid(2).MoI = [67.839047459070869 110.19097513335605 47.661070526614566];  % kg*mm^2
smiData.Solid(2).PoI = [2.8948497265629074 0 0];  % kg*mm^2
smiData.Solid(2).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(2).opacity = 1;
smiData.Solid(2).ID = 'Frame*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(3).mass = 0.0003463605900582749;  % kg
smiData.Solid(3).CoM = [0 12.499999999999995 0];  % mm
smiData.Solid(3).MoI = [0.022772472485553377 0.0011530626786378786 0.022772472485553377];  % kg*mm^2
smiData.Solid(3).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(3).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(3).opacity = 1;
smiData.Solid(3).ID = 'Pin*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(4).mass = 0.010799224746714912;  % kg
smiData.Solid(4).CoM = [0 0 0];  % mm
smiData.Solid(4).MoI = [2.1549403014371822 4.1644510429519377 2.1549403014371831];  % kg*mm^2
smiData.Solid(4).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(4).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(4).opacity = 1;
smiData.Solid(4).ID = 'Wheel*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(5).mass = 0.0085822084404263421;  % kg
smiData.Solid(5).CoM = [1.7183134757030869 34.802058214232353 0];  % mm
smiData.Solid(5).MoI = [3.0919419649744841 2.7495720165117064 4.5038127380746129];  % kg*mm^2
smiData.Solid(5).PoI = [0 0 -0.18098796614101578];  % kg*mm^2
smiData.Solid(5).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(5).opacity = 1;
smiData.Solid(5).ID = 'Wheel_frame*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(6).mass = 0.003099181152766332;  % kg
smiData.Solid(6).CoM = [0 0 -77];  % mm
smiData.Solid(6).MoI = [6.4166016458691519 6.4166016458691519 0.01014675522247249];  % kg*mm^2
smiData.Solid(6).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(6).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(6).opacity = 1;
smiData.Solid(6).ID = 'Rear_axle*:*Default';


%============= Joint =============%
%X Revolute Primitive (Rx) %Y Revolute Primitive (Ry) %Z Revolute Primitive (Rz)
%X Prismatic Primitive (Px) %Y Prismatic Primitive (Py) %Z Prismatic Primitive (Pz) %Spherical Primitive (S)
%Constant Velocity Primitive (CV) %Lead Screw Primitive (LS)
%Position Target (Pos)

%Initialize the PlanarJoint structure array by filling in null values.
smiData.PlanarJoint(1).Rz.Pos = 0.0;
smiData.PlanarJoint(1).Px.Pos = 0.0;
smiData.PlanarJoint(1).Py.Pos = 0.0;
smiData.PlanarJoint(1).ID = '';

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.PlanarJoint(1).Rz.Pos = 79.380789088730381;  % deg
smiData.PlanarJoint(1).Px.Pos = 0;  % mm
smiData.PlanarJoint(1).Py.Pos = 0;  % mm
smiData.PlanarJoint(1).ID = '[Frame-1:-:Wheel-1]';


%Initialize the RevoluteJoint structure array by filling in null values.
smiData.RevoluteJoint(6).Rz.Pos = 0.0;
smiData.RevoluteJoint(6).ID = '';

smiData.RevoluteJoint(1).Rz.Pos = 170.71105199003492;  % deg
smiData.RevoluteJoint(1).ID = '[Wheel_frame-1:-:Front_axle-2]';

smiData.RevoluteJoint(2).Rz.Pos = 177.39266993927603;  % deg
smiData.RevoluteJoint(2).ID = '[Front_axle-2:-:Wheel-4]';

smiData.RevoluteJoint(3).Rz.Pos = 169.38078908873038;  % deg
smiData.RevoluteJoint(3).ID = '[Rear_axle-1:-:Wheel-1]';

smiData.RevoluteJoint(4).Rz.Pos = -179.77914046531001;  % deg
smiData.RevoluteJoint(4).ID = '[Rear_axle-1:-:Wheel-2]';

smiData.RevoluteJoint(5).Rz.Pos = 0;  % deg
smiData.RevoluteJoint(5).ID = '[Frame-1:-:Pin-1]';

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.RevoluteJoint(6).Rz.Pos = 115.28529475447496;  % deg
smiData.RevoluteJoint(6).ID = '[Pin-1:-:Wheel_frame-1]';

